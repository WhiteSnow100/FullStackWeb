import './App.css';

import BookFinder from './components/BookFinder';

function App() {
  return <BookFinder />;
}

export default App;
