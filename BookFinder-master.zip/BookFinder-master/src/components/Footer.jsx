import "./Footer.css";

export default function Footer() {
  return (
    <footer>
      <h3>© 2024 Book Finder LDY</h3>
    </footer>
  );
}
