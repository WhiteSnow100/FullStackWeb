import "./Header.css";
export default function Header() {
  return (
    <header>
      <h1>Book Finder</h1>
    </header>
  );
}
