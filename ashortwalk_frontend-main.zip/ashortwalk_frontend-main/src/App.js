import './App.css';
import Post from './component/posts/Post.jsx';

function App() {
  return (
    <div>
      <Post/>
    </div>
  );
}


export default App;
