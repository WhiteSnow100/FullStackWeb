import "./Left.css"

export default function Left(){
    return(
        <div className="Lcontent">
            <div className="ImgBox">
                <img src="" alt="" />
            </div>
            <div className="PostComment">
                <h2>서울 숲 공기가 너무 맑아요</h2>
                <p>seoulsoup</p>
                <p>2024. 10. 30.</p>
            </div>
        </div>
    )
}