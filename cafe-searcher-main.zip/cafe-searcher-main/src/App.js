import "./App.css";
import CafeSearcher from "./components/CafeSearcher";

function App() {
  return (
    <div className="App">
      <CafeSearcher />
    </div>
  );
}

export default App;
