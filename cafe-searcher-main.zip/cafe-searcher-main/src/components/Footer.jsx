import "./Footer.css";

export default function Footer() {
  return <footer> ©️ verdantjuly All rights reserved</footer>;
}
