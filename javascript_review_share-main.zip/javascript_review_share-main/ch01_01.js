// javascript에서는 console.log로 디버깅
console.log("Hello World");
console.log("Hello World");

// 백틱을 사용하면 문자열 안에 변수를 넣을 수 있음
var world = "world";
console.log(`Hello ${world}`);
