console.log(23 + 45);
console.log('this is "string"'); // \를 사용하여 따옴표 출력 가능

// 템플릿 문자열
console.log(`52 + 45 = ${52 + 45}`);

console.log("Hello" + "javascript");

// 줄바꿈
console.log("Hello \n World");
// 탭
console.log("Hello \t World");

console.log(52 > 52); // false
console.log(52 >= 52); // true
console.log(45 == 52); // false
console.log(45 != 52); // true

console.log(52 >= 52 && 52 > 52); // true & false => false
console.log(52 >= 52 || 52 > 52); // true || false => true
