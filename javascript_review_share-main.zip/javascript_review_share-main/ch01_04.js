// 증감 연산자
let num = 1;
console.log(num); // 1
num++; // num = num + 1
console.log(num); // 2
num--; // num = num - 1
console.log(num); // 1
