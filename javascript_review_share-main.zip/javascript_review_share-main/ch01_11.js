let test;
console.log(typeof test);

test = typeof test != "undefined" ? test : "initial";
console.log(test);
