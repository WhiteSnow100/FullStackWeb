let arr = [5, 23, "hello", true, "world", -9];
let i = 0;
while (i < arr.length) {
  console.log(` ${i} => ${arr[i]}`);
  i++;
}
