let arr = [5, 23, "hello", true, "world", -9];

for (let i = 0; i < arr.length; i++) {
  console.log(`${i} => ${arr[i]}`);
}
