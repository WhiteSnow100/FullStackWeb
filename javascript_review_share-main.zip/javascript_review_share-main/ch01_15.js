let arr = [5, 23, "hello", true, "world", -9];
for (i in arr) {
  console.log(`${i} => ${arr[i]}`);
}
