let arr = [5, 23, "hello", true, "world", -9];
for (element of arr) {
  console.log(`${element}`);
}
