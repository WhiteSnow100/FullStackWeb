let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

const arr2 = arr.map((num) => num * 2);
const arr3 = arr.map(function (num) {
  return num * 2;
});
