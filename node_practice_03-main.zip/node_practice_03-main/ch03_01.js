const add = (a, b) => {
  return a + b;
};
const substract = (a, b) => {
  return a - b;
};

module.exports.substract = substract;
module.exports.add = add;
