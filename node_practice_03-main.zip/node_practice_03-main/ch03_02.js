// module 을 사용할 팡리
const calc = require("./ch03_01");
console.log(`2 + 3 = ${calc.add(2, 3)}`);

// 문제) 10 - 7 = 3
console.log(`10 - 7 = ${calc.substract(10, 7)}`);
