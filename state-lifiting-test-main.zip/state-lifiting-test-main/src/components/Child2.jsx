export default function Child2({ displayValue }) {
  return (
    <div>
      <p>입력된 값 : {displayValue}</p>
    </div>
  );
}
